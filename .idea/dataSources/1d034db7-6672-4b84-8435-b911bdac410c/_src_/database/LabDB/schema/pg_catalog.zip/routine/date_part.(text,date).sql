create function date_part(text, date) returns double precision
IMMUTABLE
LANGUAGE SQL
AS $$
select pg_catalog.date_part($1, cast($2 as timestamp without time zone))
$$;
